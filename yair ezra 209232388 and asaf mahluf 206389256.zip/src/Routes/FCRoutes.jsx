import React from 'react'
import { Route, Routes } from 'react-router-dom'
import FCLogin from '../Pages/FCLogin'
import FCMain from '../Pages/FCMain'
import FCNotes from '../Pages/FCNotes'
import FCRegister from '../Pages/FCRegister'




export default function FCRoutes() {
    return (
        <div style={{ margin: 20, fontSize: 25, color: 'red' }}>
            <Routes>
                <Route path='/' element={<FCLogin />} />
                <Route path='/register' element={<FCRegister />} />
                <Route path='/main' element={<FCMain />} />
                <Route path='/notes' element={<FCNotes />} />

            </Routes>
        </div>
    )
}
