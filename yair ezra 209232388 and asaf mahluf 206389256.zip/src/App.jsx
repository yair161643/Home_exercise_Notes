import './App.css';
import FCRoutes from './Routes/FCRoutes';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <FCRoutes />
      </header>
    </div>
  );
}

export default App;
