import React, { useContext, useState } from 'react'
import { NotesContext } from '../Context/NoteContextProvider'
import { Link } from 'react-router-dom';
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import { Alert, Button, TextField } from '@mui/material';
import { Snackbar } from '@mui/material';

export default function FCMain() {
  const [title, setTitle] = useState('')
  const [desc, setDesc] = useState('')
  const { addToNotes } = useContext(NotesContext)
  const [open, setOpen] = React.useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
        return;
    }

    setOpen(false);
};
  const btnAddNote = () => {
    if (title !== '' && desc !== '') {
      addToNotes(title, desc);
      setOpen(true);
      setErrorMessage("Note added successfully");
    } else {
      setOpen(true);
      setErrorMessage("Both fields are required");
    }
  }

  return (

    <div style={{ background: "linear-gradient(to right, lightblue, black)", width: "100%", border: "1px solid lightblue", padding: "50px 25px 50px 25px", display: "flex", flexDirection: "column", gap: "15px" }}>
      <h1 style={{ color: "lightblue" }}>MAIN</h1>

      <TextField id="outlined-basic" label="Title" variant="outlined" onChange={(e) => setTitle(e.target.value)}></TextField>

      <TextField id="outlined-basic" label="Description" variant="outlined" onChange={(e) => setDesc(e.target.value)}></TextField>
      <Button onClick={btnAddNote}>Add note</Button> <br />

      <Link style={{ color: "lightblue" }} to={"/notes"} > Go 2 Notes Page </Link>

      <Snackbar open={open} autoHideDuration={1500} onClose={handleClose} anchorOrigin={{ vertical: 'top', horizontal: "center" }}>
        <Alert onClose={handleClose} severity={errorMessage === "Note added successfully" ? "success" : "error"}>
          {errorMessage}
        </Alert>
      </Snackbar>
    </div >
  )
}