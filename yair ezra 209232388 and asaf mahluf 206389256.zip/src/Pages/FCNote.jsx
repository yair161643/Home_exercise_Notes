import React, { useContext } from 'react'
import { NotesContext } from '../Context/NoteContextProvider'
import DeleteIcon from '@mui/icons-material/Delete';



export default function FCNote(props) {

  const { DeleteFromNotes } = useContext(NotesContext)


  const btnDeleteNote = () => {
    DeleteFromNotes(props.id)
  }




  return (
    <div style={{ border: "3px white solid", width: "100%", borderRadius: "50px",color:"lightblue" }}>
      {props.title} -- {props.desc} <br />
       <button onClick={() => btnDeleteNote(props)}>
       <DeleteIcon></DeleteIcon>
        </button>
        
    </div>
  )
}
