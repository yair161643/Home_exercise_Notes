import React, { useContext, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { UserContext } from '../Context/UserContextProvider';
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import { Alert, Button, Snackbar, TextField } from '@mui/material';

export default function FCRegister() {
  const navigate = useNavigate();
  const { fromRegisterToUsersList } = useContext(UserContext);
  const [email, setEmail] = useState('')
  const [password1, setPassword1] = useState('')
  const [password2, setPassword2] = useState('')
  const [showPopup, setShowPopup] = useState(false) // New state variable
  const [errorMessage, setErrorMessage] = useState("");

  const [open, setOpen] = React.useState(false);

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
        return;
    }

    setOpen(false);
};

  const regexEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
  const regexPassword = /^.{6,}$/

  const btnSubmitRegister = () => {
    let goodEmail = true
    let goodPassword = true
    if (password1 !== password2) {
      setOpen(true);
      setErrorMessage("PASSWORD DIFFERENT");
      goodPassword = false
    }
    if (!(regexEmail.test(email))) {
      setOpen(true);
      setErrorMessage("Email Not good");
      goodEmail = false
    }
    if (!(regexPassword.test(password1))) {
      setOpen(true);
      setErrorMessage("Password Not good");
      goodPassword = false
    }
    if (goodEmail && goodPassword) {
      let userExistInUsers = fromRegisterToUsersList(email, password1)
      if (!userExistInUsers) { 
        navigate('/')
      }
      else if (userExistInUsers) { 
       setOpen(true);
       setErrorMessage("User already exists");
      }
    }
  }


  return (
    <div style={{ background: "linear-gradient(to right, lightblue, black)", width: "100%", border: "1px solid lightblue", padding: "50px 25px 50px 25px", display: "flex", flexDirection: "column", gap: "15px" }}>
      <h1 style={{ color: "lightblue" }}>REGISTER</h1>

      <TextField id="outlined-basic" label="Email" variant="outlined" onChange={(e) => { setEmail(e.target.value) }}></TextField>

      <TextField type={"password"} id="outlined-basic" label="Password" variant="outlined" onChange={(e) => setPassword1(e.target.value)}></TextField>
      <TextField style={{ backgroundColor: password1 !== password2 && password2 !== '' ? 'red' : '' }} type={"password"} id="outlined-basic" label="Confirm Password" variant="outlined"
    onChange={(e) => {
      setPassword2(e.target.value)
    }}></TextField>

  <Button style={{ color: "lightblue" }} onClick={btnSubmitRegister}>Sumbit</Button>
<img src="" alt="" />
  

<Snackbar open={open} autoHideDuration={3000} onClose={handleClose}  anchorOrigin={{ vertical:'top', horizontal:"center" }}>
        <Alert onClose={handleClose} severity="error">
          {errorMessage}
        </Alert>
</Snackbar>

     


</div >
)
}
