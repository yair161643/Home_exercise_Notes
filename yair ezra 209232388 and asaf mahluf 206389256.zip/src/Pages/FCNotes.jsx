import React, { useContext } from 'react'
import { NotesContext } from '../Context/NoteContextProvider';
import FCNote from './FCNote';
import { Link } from 'react-router-dom';
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import { Button, TextField } from '@mui/material';




export default function FCNotes() {


  const { notes } = useContext(NotesContext)



  let strNotes = notes.map(avi =>
    <FCNote
      key={avi.id}
      id={avi.id}
      title={avi.title}
      desc={avi.desc}
    />
  )

  return (

    <div style={{ background: "linear-gradient(to right, lightblue, black)", width: "400px", height: "100%", border: "1px solid lightblue", padding: "50px 25px 50px 25px", display: "flex", flexDirection: "column", gap: "15px" }}>
      <h1 style={{ color: "lightblue" }}>NOTES</h1>

      <div style={{ width: "100%", display: "flex", gap: "15px", flexWrap: "wrap", justifyItems: "center", justifyContent: "center", flexDirection: "column" }}>
        {strNotes}
      </div>

      <Link style={{ color: "lightblue" }} to={"/main"} > Go 2 Main Page </Link>


    </div>
  )
}
