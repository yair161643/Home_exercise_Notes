import React, { useContext, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { UserContext } from '../Context/UserContextProvider';
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import { Button, TextField } from '@mui/material';
import { Link } from 'react-router-dom';
import { Snackbar, Alert } from '@mui/material';

export default function FCLogin() {

    const [Email, setEmail] = useState('')
    const [Password, setPassword] = useState('')
    const { fromLoginToCheckIfExist } = useContext(UserContext);
    const navigate = useNavigate();
    const [open, setOpen] = React.useState(false);
    const [errorMessage, setErrorMessage] = useState('');

    const handleClick = () => {
        setOpen(true);
    };

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
            return;
        }

        setOpen(false);
    };

    // ---------- Click Login
    const btnLoginPress = () => {
        let userCheckExist = fromLoginToCheckIfExist(Email, Password)
        if (userCheckExist !== null && userCheckExist !== undefined) { 
            navigate("/main");
        }
        else {
            setOpen(true);
            setErrorMessage("We don't know you");
        }
    }

    return (

        <div style={{ background: "linear-gradient(to right, lightblue, black)", width: "100%", border: "1px solid lightblue", padding: "50px 25px 50px 25px", display: "flex", flexDirection: "column", gap: "15px" }}>
            <h1 style={{ color: "lightblue" }}>LOGIN</h1>

            <TextField id="outlined-basic" label="Email" variant="outlined" onChange={(e) => setEmail(e.target.value)}></TextField>

            <TextField type={"password"} id="outlined-basic" label="Password" variant="outlined" onChange={(e) => setPassword(e.target.value)}></TextField>

            <Button style={{ color: "white" }} onClick={btnLoginPress}>Login</Button> <br />

            <Link style={{ color: "lightblue" }} to={"/register"} > Press here to register </Link>

            <Snackbar open={open} autoHideDuration={3000} onClose={handleClose}  anchorOrigin={{ vertical:'top', horizontal:"center" }}>
                <Alert onClose={handleClose} severity="error">
                    {errorMessage}
                </Alert>
            </Snackbar>
        </div>
    )
}

