import React, { createContext, useState } from 'react'

export const UserContext = createContext()

export default function UserContextProvider(props) {

  const [users, setUsers] = useState([
    { email: "asaf@gmail.com", password: "1234567" }
  ])





  // -----------------  מהרשמה לרשימה
  const fromRegisterToUsersList = (email, password) => {
    let newUser = { email, password };
    let ifExistUser = users.find(avi => avi.email === email)
    if (ifExistUser !== null && ifExistUser !== undefined) { // אם הוא מצא את המייל כחלק מהרשימה הכוונה שקיים משתמש כזה, אז יחזיר אמת
      return (true)
    }
    let newUsers = [...users, newUser];
    setUsers(newUsers);
  }


  // -----------------  בדיקה אחרי התחברות אם קיים משתמש כזה במערכת
  const fromLoginToCheckIfExist = (userEmail, password) => {
    let newUser = users.find(avi => avi.email === userEmail && avi.password === password)
    return newUser
  }











  return (
    <UserContext.Provider value={{ users, fromRegisterToUsersList, fromLoginToCheckIfExist }}>
      {props.children}

    </UserContext.Provider>
  )
}
