import React, { createContext, useEffect, useState } from 'react'

export const NotesContext = createContext()

export default function NoteContextProvider(props) {



    const [notes, setNotes] = useState([
        { id: 0, title: "title 1 examp", desc: "lorem ipsum was here" },
        { id: 1, title: "title 2 examp", desc: "lorem ipsum brother was here" }
    ])


    const DeleteFromNotes = (id) => {
        let updatedNotes = notes.filter(note => note.id !== id);
        setNotes(updatedNotes)
    }


    const addToNotes = (title, desc) => {
        let newNote = { id: notes.length + 1, title, desc }
        let allNotes = [...notes, newNote]
        setNotes(allNotes)
        



    }

    useEffect(() => {

        console.log(JSON.stringify(notes));

    }, [notes])






    return (
        <NotesContext.Provider value={{ notes, DeleteFromNotes, addToNotes }}>
            {props.children}

        </NotesContext.Provider>
    )
}
